package checkers;

import checkers.checkergame.Game;

public class MainClass {
    public static void main(String[] args) {
        Game.startGame();
    }
}
