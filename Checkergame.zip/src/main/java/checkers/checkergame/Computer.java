package checkers.checkergame;

public class Computer extends Player {

    public Computer() {
        super("Arteefy Shole", -1);
    }

    public void analyzeBoard() {
        // TODO - Implement logic
        /**
         * Analyze board to collect data & identify potential action-cases
         */
    }
}
